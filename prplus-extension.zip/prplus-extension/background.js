// Listen for messages from the main app
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
        // Handle ping to check if extension exists
        if (request.action === 'ping') {
            sendResponse({ status: 'success' });
            return;
        }

        // Handle saving pitch data
        if (request.action === 'savePitch') {
            chrome.storage.local.set(request.data, function() {
                sendResponse({ status: 'success' });
            });
            return true; // Will respond asynchronously
        }
    }
);

// Listen for messages from content script
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.action === 'submitQuote') {
            // Handle any post-submission tasks if needed
            sendResponse({ status: 'success' });
        }
    }
);
