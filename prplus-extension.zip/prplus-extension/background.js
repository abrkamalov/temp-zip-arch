// Listen for messages from the main app
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
        // Handle ping to check if extension exists
        if (request.action === 'ping') {
            sendResponse({ status: 'success' });
            return;
        }

        // Handle saving pitch data
        if (request.action === 'savePitch') {
            chrome.storage.local.set(request.data, function() {
                sendResponse({ status: 'success' });
            });
            return true; // Will respond asynchronously
        }
    }
);

// Listen for messages from content script
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.action === 'submitQuote') {
            // Handle any post-submission tasks if needed
            sendResponse({ status: 'success' });
        }

        // Handle getting pitch data
        if (request.action === 'getPitchData') {
            chrome.storage.local.get([request.key], function(result) {
                sendResponse({ data: result[request.key] });
            });
            return true; // Will respond asynchronously
        }

        // Handle cleaning up storage
        if (request.action === 'cleanupStorage') {
            chrome.storage.local.remove([request.key]);
            sendResponse({ status: 'success' });
        }

        // Handle getting return URL
        if (request.action === 'getReturnUrl') {
            chrome.storage.local.get(['returnUrl'], function(result) {
                sendResponse({ returnUrl: result.returnUrl });
            });
            return true; // Will respond asynchronously
        }

        // Handle cleaning up return URL
        if (request.action === 'cleanupReturnUrl') {
            chrome.storage.local.remove(['returnUrl']);
            sendResponse({ status: 'success' });
        }
    }
);
