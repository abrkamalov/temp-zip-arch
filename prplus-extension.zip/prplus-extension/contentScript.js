// Listen for URL parameters when page loads
const urlParams = new URLSearchParams(window.location.search);
const storageKey = urlParams.get('storageKey');
console.log('Storage key from URL:', storageKey);

// Helper function to find element by text content with optional parent selector
const findElementByText = (selector, text, parentSelector = null) => {
    console.log(`Looking for element: ${selector} with text: ${text}${parentSelector ? ` in parent: ${parentSelector}` : ''}`);
    let elements;
    if (parentSelector) {
        const parent = document.querySelector(parentSelector);
        if (!parent) {
            console.log(`Parent element not found: ${parentSelector}`);
            return null;
        }
        elements = parent.querySelectorAll(selector);
    } else {
        elements = document.querySelectorAll(selector);
    }

    console.log(`Found ${elements.length} matching elements`);
    const element = Array.from(elements).find(element => {
        const elementText = element.textContent.trim().toLowerCase();
        const searchText = text.toLowerCase();
        const ariaLabel = (element.getAttribute('aria-label') || '').toLowerCase();
        console.log(`Comparing text: "${elementText}" with "${searchText}"`);
        console.log(`Aria label: "${ariaLabel}"`);
        return elementText === searchText ||
               elementText.includes(searchText) ||
               ariaLabel.includes(searchText) ||
               elementText.includes('pitch') ||
               ariaLabel.includes('pitch');
    });

    console.log(element ? `Found element with text: ${text}` : `No element found with text: ${text}`);
    return element;
};

// Function to wait for an element to be present in the DOM
const waitForElement = (selector, text = null, parentSelector = null, timeout = 10000) => {
    console.log(`Waiting for element: ${selector}${text ? ` with text: ${text}` : ''}${parentSelector ? ` in parent: ${parentSelector}` : ''}`);
    return new Promise((resolve, reject) => {
        const startTime = Date.now();

        // First check if element already exists
        if (text) {
            const element = findElementByText(selector, text, parentSelector);
            if (element) {
                console.log('Element found immediately');
                return resolve(element);
            }
        } else {
            const element = document.querySelector(selector);
            if (element) {
                console.log('Element found immediately');
                return resolve(element);
            }
        }

        console.log('Element not found immediately, starting observer...');
        // If not found, observe DOM for changes
        const observer = new MutationObserver(mutations => {
            let element;
            if (text) {
                element = findElementByText(selector, text, parentSelector);
            } else {
                element = document.querySelector(selector);
            }

            if (element) {
                console.log('Element found after DOM mutation');
                observer.disconnect();
                resolve(element);
            } else if (Date.now() - startTime > timeout) {
                console.log('Timeout reached while waiting for element');
                observer.disconnect();
                reject(new Error(`Timeout waiting for element: ${selector} ${text || ''}`));
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
};

// Add delay function
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Main automation function
async function automateQwotedPitch() {
    console.log('Starting Qwoted pitch automation');
    try {
        // Get the pitch data from storage
        chrome.storage.local.get([storageKey], async function(result) {
            if (!result[storageKey]) {
                console.error('No pitch data found in storage');
                return;
            }

            console.log('Retrieved pitch data from storage:', result[storageKey]);
            const pitchData = result[storageKey];

            try {
                // Try to find Start a Pitch button quickly
                try {
                    console.log('Quick check for Start a Pitch button...');
                    const startPitchButton = document.querySelector('button.btn-primary span:not([aria-hidden="true"]):not(.fa-solid)');
                    if (startPitchButton && startPitchButton.textContent.trim() === 'Start a Pitch') {
                        console.log('Found Start a Pitch button immediately, clicking...');
                        startPitchButton.closest('button').click();
                    }
                } catch (e) {
                    console.log('No Start a Pitch button found, continuing...');
                }

                // Wait a moment for any animations
                await delay(1000);

                // Look for the Expert button immediately
                console.log('Looking for Expert button...');
                let expertButton = document.querySelector('#add_source');
                if (!expertButton) {
                    console.log('Expert button not found by ID, trying other selectors...');
                    const possibleButtons = document.querySelectorAll('[role="button"], button, .btn');
                    console.log('Found possible buttons:', Array.from(possibleButtons).map(b => ({
                        text: b.textContent.trim(),
                        id: b.id,
                        classes: b.className,
                        role: b.getAttribute('role')
                    })));

                    expertButton = Array.from(possibleButtons).find(b =>
                        b.id === 'add_source' ||
                        b.textContent.toLowerCase().includes('expert') ||
                        (b.querySelector('i.fa-user-tie') !== null)
                    );
                }

                if (expertButton) {
                    console.log('Found expert button:', {
                        text: expertButton.textContent.trim(),
                        id: expertButton.id,
                        classes: expertButton.className
                    });
                    expertButton.click();
                    console.log('Clicked expert button');
                } else {
                    console.error('Could not find Expert button');
                    return;
                }

                await delay(1000);

                // Wait for search field and type expert name
                console.log('Looking for search field...');
                const searchField = await waitForElement('input[placeholder="Search..."]');
                console.log('Found search field, typing expert name:', pitchData.expertName);
                searchField.value = pitchData.expertName;
                searchField.dispatchEvent(new Event('input', { bubbles: true }));
                await delay(1000);

                // Wait for and click "Attach" button when expert is found
                console.log('Looking for Attach button...');
                const attachButton = await waitForElement('button.btn-outline-primary', 'Attach');
                console.log('Found Attach button, clicking...');
                attachButton.click();
                await delay(1000);

                // Get reporter's first name
                console.log('Looking for reporter name...');
                const reporterLink = document.querySelector('a.fw-bold[href^="/reporters/"]');
                let reporterFirstName = '';
                if (reporterLink) {
                    reporterFirstName = reporterLink.textContent.trim().split(' ')[0];
                    console.log('Found reporter first name:', reporterFirstName);
                }

                // Wait for pitch text area and paste the pitch
                console.log('Looking for pitch text area...');
                const pitchTextArea = await waitForElement('textarea');
                console.log('Found pitch text area, pasting content...');
                let pitchText = pitchData.copiedText;
                if (reporterFirstName) {
                    pitchText = pitchText.replace('<<reporterFirstName>>', reporterFirstName);
                }
                pitchTextArea.value = pitchText;
                pitchTextArea.dispatchEvent(new Event('input', { bubbles: true }));

                // Wait for user to click Submit
                console.log('Waiting for user to click Submit...');
                const submitButton = await waitForElement('button.btn-primary', 'Submit');

                // Create a promise that resolves when the submit button is clicked
                const submitClickPromise = new Promise(resolve => {
                    submitButton.addEventListener('click', resolve, { once: true });
                });

                // Wait for the click
                await submitClickPromise;
                console.log('Submit button clicked, waiting for navigation...');

                // Wait for the next page to load
                await new Promise(resolve => {
                    // Create an observer to watch for URL changes
                    const observer = new MutationObserver((mutations, obs) => {
                        if (window.location.href.includes('pitch_created=true')) {
                            obs.disconnect();
                            resolve();
                        }
                    });

                    observer.observe(document.body, {
                        childList: true,
                        subtree: true
                    });

                    // Also set a timeout to resolve after 10 seconds if no URL change
                    setTimeout(resolve, 10000);
                });

                console.log('Navigation complete, closing tab...');

                // Clean up storage
                chrome.storage.local.remove([storageKey]);

                // Get the return URL from storage
                chrome.storage.local.get(['returnUrl'], function(result) {
                    const returnUrl = result.returnUrl;
                    if (returnUrl) {
                        // Remove the return URL from storage
                        chrome.storage.local.remove(['returnUrl']);
                        // Navigate back to the web app
                        window.location.href = returnUrl;
                    } else {
                        // If no return URL, just close the tab
                        window.close();
                    }
                });

            } catch (error) {
                console.error('Automation error:', error);
                console.error('Error stack:', error.stack);
            }
        });
    } catch (error) {
        console.error('Error during Qwoted automation:', error);
        console.error('Error stack:', error.stack);
    }
}

// Start automation if we have a storage key
if (storageKey) {
    console.log('Starting automation process...');
    // Wait for page to be fully loaded
    if (document.readyState === 'complete') {
        console.log('Page already loaded, starting immediately');
        automateQwotedPitch();
    } else {
        console.log('Waiting for page to load...');
        window.addEventListener('load', automateQwotedPitch);
    }
} else {
    console.log('No storage key found in URL');
}
