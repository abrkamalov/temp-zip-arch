document.getElementById("start").addEventListener("click", async () => {
  const storageKey = 'pitch_' + Date.now();

  // Get token from platform's localStorage
  const token = localStorage.getItem('jwtToken'); // Adjust key name as needed

  if (!token) {
    console.error('No authentication token found. Please log in to the platform first.');
    return;
  }

  const pitchData = {
    copiedText: "Hello <<JName>>, here is the response to your inquiry.",
    queryID: queryID,
    leadID: leadID,
    token: token
  };

  await chrome.storage.local.set({ [storageKey]: pitchData });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const qwotedUrl = `https://qwoted.com/specific-quote-page?storageKey=${storageKey}`;
    chrome.tabs.update(tabs[0].id, { url: qwotedUrl });
  });
});
